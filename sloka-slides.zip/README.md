# Śloka Slides — Verse Presenter (Chrome extension)

Turns scripture pages (verse number, Devanāgarī, transliteration, word-for-word, translation, purport)
into a clean, distraction-free slideshow for classes.

## Install (1 minute)
1. Unzip `sloka-slides.zip` (or use this folder).
2. Open `chrome://extensions`, switch on **Developer mode** (top-right).
3. Click **Load unpacked** and choose the `verse-slides` folder.
4. Pin the orange lotus icon to the toolbar.

## Everyday use
| What you want | How |
|---|---|
| Present one verse page | Click the icon → **Present this page** (or `Alt+Shift+S`) |
| Present only some verses of a chapter page | Select them with the mouse → **Present selection** |
| Verses spread over many pages | On each page **Add to collection** (`Alt+Shift+A`) → **Present collection** |
| A whole chapter from its contents page | Select the links → **Present linked pages** (fetches each page) |
| Any copied text | **Paste text** |
| A site the extension doesn't understand | **Map this site** → click *Pick* and point at each part |

Right-click menus offer the same actions.

## In the slideshow
`→ / Space / PgDn` next · `← / PgUp` back · `↓ / ↑` next/previous verse · `T` quick tools (theme, font, size,
line/letter/word spacing, width, alignment, section sizes, what to show, layout) · `G` or `/` verse list & search ·
`J` jump to verse · `+ / − / 0` text size · `D` light/dark · `F` full screen · `A` auto-advance (fixed time or
reading pace) · `B / W` black/white screen · `L` laser pointer · `S` spotlight · `H` highlighter (click words) ·
`1–5` show/hide Devanāgarī, transliteration, word-for-word, translation, purport · `?` help.

The thin bar along the bottom shows progress (hover it to see verses, click to jump; ticks mark verse starts).
The current verse is shown faded in the bottom-right corner.

## How slides are filled
- **Fit as much as fits** (default): verse number on top, then the verse, word-for-word, translation and purport,
  flowing onto the next slide only when the screen is full. Long purports are split at sentence boundaries,
  with a “Purport · continued” label.
- **One section per slide**: each section starts a fresh slide.
- Short verses without purport are combined onto one slide when they fit (can be switched off).
Everything re-flows instantly when you change the font, size or spacing, keeping your place.

## Site mappings
Vedabase.io has a built-in (best-effort) mapping; any other site works through smart text detection
(headings like “Synonyms / Translation / Purport” and verse numbers like “ŚB 8.1.2” or “Text 2”)
or through a mapping you create with **Map this site**. Mappings can be edited, exported and shared from
**Settings → Site mappings**.

## Files
- `manifest.json` — Manifest V3
- `src/common.js` — shared parsing, themes, fonts, settings
- `src/content.js` — page extraction + interactive site mapper (injected only when you use the extension)
- `src/background.js` — commands, context menus, collection, deck storage
- `slides/` — the slideshow · `options/` — settings page · `popup/` — toolbar popup

Permissions: `activeTab` + `scripting` (read the page only when you click), `storage`, `contextMenus`.
Fonts load from Google Fonts when online and fall back to system fonts offline.
